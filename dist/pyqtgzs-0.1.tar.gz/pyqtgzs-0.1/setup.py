from setuptools import setup
setup(name='pyqtgzs',
      version='0.1',
      description='QinTian_QAQ',
      url='qtgzsceo.github.io',
      author='Ling',
      author_email='qtgzs666@163.com',
      license='MIT',
      packages=['pyqtgzs'],
      zip_safe=False)